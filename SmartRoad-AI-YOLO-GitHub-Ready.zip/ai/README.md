# AI Module
Pipeline:
`Video/Webcam → YOLO → Vehicle filtering → Parking-zone test → Congestion estimation → Annotated video + JSON`

Run:
```bash
python ai/detect.py --source data/road.mp4
```

The first run may download model weights automatically. Parking-zone coordinates are prototype values and should be adjusted for your own camera/video.
